###S.I.M. Changelog

#####`v0.4003.1`
[CHANGED] Versioning system (is now scarCODE's global versioning) <br />
[CHANGED] Menu layout <br />
[NEW] Blur when menu is open <br />

*Old version changlogs not included*
