# serverLogo script by IT07
### For ArmA 3 EPOCH mod

##### INSTALLATION
**1)** Merge your description.ext with the one provided with this repository sub-folder <br />
**2)** Copy and merge the scarCODE from this repository into the root of your mission file <br />

##### CONFIGURATION
You can of course change the image used as logo. Edit line 9 of `scarCODE\SL\functions_SL\fn_showWatermark.sqf` to fit your needs :) <br />
The logo must have a 2:1 ratio. Example sizes: *128x64*, *256x128*, *512x256*, too big: *1024x512*, *2048x1024*
