class SC_sarDiag
{
	idd = 291;
	onLoad = "[_this] spawn SC_fnc_loadSAR";
	movingEnable = true;
	class controls
	{
		#include "rsc_SAR.hpp"
	};
};