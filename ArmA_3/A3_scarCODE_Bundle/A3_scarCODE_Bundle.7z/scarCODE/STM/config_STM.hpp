class stmConfig
{
	class Settings
	{
		map = "Altis"; // Obvious, right?
		tpLocations[] = {"West","Central","East"};
		tpCoords[] = {{6182.43,16836.5,0.00157166},{13326.6,14515.5,0.00143862},{18454.5,14277.5,0.00127983}};
	};
};