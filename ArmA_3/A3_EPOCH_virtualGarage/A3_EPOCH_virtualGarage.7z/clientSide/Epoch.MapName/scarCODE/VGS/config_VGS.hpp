/*
	Author: IT07

	Description:
	Configuration and resource file for Virtual Garage System.
*/

class cfgVGSclient
{
	// Settings here
	range = 25; // Vehicles within this range of player can be moved into garage
};
