class scarCODE
{
    tag = "SC"; // Put two slashes in front of the #include line if you do not have the file which it is trying to #include
    #include "scripts\GlobalMessenger\cfgFunctions.hpp"
    #include "scripts\introCredits\cfgFunctions.hpp"
    #include "scripts\MainMenu\cfgFunctions.hpp"
    #include "scripts\ServerInfoMenu\cfgFunctions.hpp"
    #include "scripts\ServerLogo\cfgFunctions.hpp"
    #include "scripts\ServerRestartWarning\cfgFunctions.hpp"
};
