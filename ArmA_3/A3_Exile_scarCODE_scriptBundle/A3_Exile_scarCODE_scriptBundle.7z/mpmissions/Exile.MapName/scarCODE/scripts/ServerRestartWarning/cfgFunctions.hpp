class ServerRestartWarning
{
    file = "scarCODE\scripts\ServerRestartWarning\functions";
    class serverRestartWarningGetSetting {};
    class serverRestartWarningShow {};
    class serverRestartWarningTimeCheck {};
    class serverRestartWarningInitClient { postInit = 1; };
};
