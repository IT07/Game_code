class ServerInfoMenu
{
    file = "scarCODE\scripts\ServerInfoMenu\functions";
    class serverInfoMenuCtrlSetText {};
    class serverInfoMenuGetLiveData {};
    class serverInfoMenuGetSetting {};
    class serverInfoMenuOnLoad {};
    class serverInfoMenuOnMouseEnter {};
    class serverInfoMenuSetContent {};
    class serverInfoMenuSetLiveData {};
    class serverInfoMenuInitClientStandalone { postInit = 1; };
    class serverInfoMenuInitClient { postInit = 1; };
};
