class sc_cfgGlobalMessenger
{
    key = 0x3E; // DEFAULT: 0x3E = F4 | DIK Keycodes: https://community.bistudio.com/wiki/DIK_KeyCodes#Numeric_sort
    logo = "scarCODE\img\rscNewsLogo.paa";
    logoCorner = "scarCODE\img\rscNewsLogoCorner.paa";
};
