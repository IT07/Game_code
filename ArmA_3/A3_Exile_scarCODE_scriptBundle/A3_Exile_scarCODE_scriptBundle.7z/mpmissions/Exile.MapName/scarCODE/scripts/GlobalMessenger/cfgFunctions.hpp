class GlobalMessenger
{
    file = "scarCODE\scripts\GlobalMessenger\functions";
    class globalMessengerGetSetting {};
    class globalMessengerNewsMessage {};
    class globalMessengerSendGlobalNews {};
    class globalMessengerInitClient { postInit = 1; };
};
