class sc_cfgMainMenu
{
	customControl = "User7"; // To disable, use false. Info: https://community.bistudio.com/wiki/inputAction/actions/bindings
	useScrollMenu = 1; // To disable, use false. Default: 1 (enabled)
	installedMenus[] = {"SIM","SAR"}; // If only one specified, that menu will open straight away
};
