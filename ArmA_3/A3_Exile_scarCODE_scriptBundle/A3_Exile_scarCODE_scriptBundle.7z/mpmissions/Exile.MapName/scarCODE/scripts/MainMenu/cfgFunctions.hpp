class MainMenu
{
    file = "scarCODE\scripts\MainMenu\functions";
    class mainMenuGetSetting {};
    class mainMenuOpenSelected {};
    class mainMenuOnLoad {};
    class mainMenuInitClient { postInit = 1; };
};
