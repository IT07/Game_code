class introCredits
{
    file = "scarCODE\scripts\introCredits\functions";
    class introCreditsGetSetting {};
    class introCreditsInitClient { postInit = 1; };
};
