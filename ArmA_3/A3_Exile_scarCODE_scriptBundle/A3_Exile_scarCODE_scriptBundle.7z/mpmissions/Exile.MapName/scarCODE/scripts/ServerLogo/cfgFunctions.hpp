class ServerLogo
{
    file = "scarCODE\scripts\ServerLogo\functions";
    class serverLogoGetSetting {};
    class serverLogoShow { postInit = 1; };
};
