class sc_cfgServerLogo
{
    ////////////////////////
    serverLogo = "scarCODE\scripts\serverLogo\img\serverLogo.paa"; // Server logo config //
    ////////////////////////
};
